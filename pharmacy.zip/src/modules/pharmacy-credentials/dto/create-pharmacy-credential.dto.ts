export class CreatePharmacyCredentialDto {}
